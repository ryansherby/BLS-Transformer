# BLS-Transformer

## Description
An easy-to-use library to access Bureau of Labor Statistics data and transform the raw JSON into pandas DataFrames.

## Installation
`pip install bls-transformer`

## Usage
See the Wiki.
